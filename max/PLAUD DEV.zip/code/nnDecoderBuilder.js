autowatch = 1;

var p = this.patcher;
var decoderObj;
var currentModelName;

function getLatentsObject() {
	var finalLatentsObj = p.getnamed("final_latents_object");
  return finalLatentsObj;
}

function getPatcherOutput() {
  var outputObj = p.getnamed("patcher_output_1");
  return outputObj;
}

function getDecoderInput() {
  var inputObj = p.getnamed("decoder_input_receive");
  return inputObj;
}

function deleteDecoder() {
  decoderObj = p.getnamed("decoder_object");
  if (decoderObj) {
    p.remove(decoderObj);
  }
}


function createDecoder(modelName) {
  if (modelName === currentModelName) {
    return;
  }

  currentModelName = modelName;
  
  deleteDecoder();

  decoderObj = p.newdefault(173, 140, "nn~", modelName, "decode", 8192);
  decoderObj.varname = "decoder_object";
  decoderObj.rect = [173., 140., 800., 22.];

  var latentsObj = getLatentsObject();

  p.connect(latentsObj, 0, decoderObj, 0);
  p.connect(latentsObj, 1, decoderObj, 1);
  p.connect(latentsObj, 2, decoderObj, 2);
  p.connect(latentsObj, 3, decoderObj, 3);

  var numOutlets = decoderObj.getboxattr('numoutlets');

  var outputObj1 = p.getnamed("patcher_output_1");
  var outputObj2 = p.getnamed("patcher_output_2");
  p.connect(decoderObj, 0, outputObj1, 0);

  if (numOutlets > 1) {
  	p.connect(decoderObj, 1, outputObj2, 0);
  } else {
	p.connect(decoderObj, 0, outputObj2, 0);
  }
  
  var decoderInputObj = getDecoderInput();
  p.connect(decoderInputObj, 0, decoderObj, 0);
}
