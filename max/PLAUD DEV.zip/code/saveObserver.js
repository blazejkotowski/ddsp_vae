autowatch = 1;
outlets = 1;

var ready = false;
var observer = null;

function init() {
    observer = new LiveAPI(onModified, "live_set");
    observer.property = "is_modified";

    // open the gate after a delay
    var t = new Task(function() { ready = true; }, this);
    t.schedule(1000);
}

function onModified(args) {
    if (args[0] !== "is_modified") return;
    var val = parseInt(observer.get("is_modified"));
    if (val === 0 && ready) {
        outlet(0, "saved");
    }
}