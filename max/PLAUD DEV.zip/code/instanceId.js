autowatch = 1;

function getId() {
	var p = this.patcher.getnamed('device_uid');
	var current = p.getvalueof();
	if (!current || current == 0 || current == "0" || current === "" || (current.length === 1 && current[0] === "")) {
		current = generateUid();
		p.setvalueof(current);
	}
	outlet(0, current)
}

function generateUid() {
    return Date.now().toString(36) + "-" + Math.floor(Math.random() * 1e9).toString(36);
}