mgraphics.init();
mgraphics.relative_coords = 0;
mgraphics.autofill = 0;
autowatch = 1;
inlets = 2;
outlets = 0;
setinletassist(0, "number of channels (int)");
setinletassist(1, "selected channel (0=all, 1=ch1, 2=ch2...)");
var n_chans     = 4;
var selected_ch = -1;
var colors = [
    [0.11, 0.62, 0.46],
    [0.22, 0.54, 0.87],
    [0.94, 0.62, 0.15],
    [0.83, 0.33, 0.49],
    [0.50, 0.47, 0.87],
    [0.36, 0.79, 0.65],
    [0.94, 0.60, 0.48],
    [0.71, 0.83, 0.96],
];
function msg_int(v) {
    if (inlet == 0) {
        n_chans = Math.max(1, v);
        mgraphics.redraw();
    } else if (inlet == 1) {
        if (v == 0) {
            selected_ch = -1;
        } else {
            selected_ch = v - 1;
        }
        mgraphics.redraw();
    }
}
function bang() {
    mgraphics.redraw();
}
function paint() {
    var g = mgraphics;
    var W = box.rect[2] - box.rect[0];
    var H = box.rect[3] - box.rect[1];

    var ch_from, ch_to;
    if (selected_ch == -1) {
        ch_from = 0;
        ch_to   = n_chans - 1;
    } else {
        ch_from = Math.min(selected_ch, n_chans - 1);
        ch_to   = ch_from;
    }
    var count   = ch_to - ch_from + 1;
    var line_w  = 12;
    var spacing = Math.min(16, Math.floor(H / count));
    var pad_x   = 6;
    var pad_y   = spacing * 0.5 + 4;
    var leg_w   = pad_x + line_w + 4 + 24 + pad_x;
    var leg_h   = count * spacing + 4;

    g.set_source_rgba(0.07, 0.07, 0.08, 0.7);
    g.rectangle(0, 0, leg_w, leg_h);
    g.fill();

    for (var i = ch_from; i <= ch_to; i++) {
        var col         = colors[i % colors.length];
        var ly          = pad_y + (i - ch_from) * spacing;
        var is_selected = (selected_ch != -1 && i == selected_ch);

        g.set_source_rgba(col[0], col[1], col[2], is_selected ? 1.0 : 0.75);
        g.set_line_width(is_selected ? 2.0 : 1.5);
        g.move_to(pad_x, ly);
        g.line_to(pad_x + line_w, ly);
        g.stroke();

        g.set_source_rgba(1.0, 1.0, 1.0, is_selected ? 0.9 : 0.45);
        g.set_font_size(9);
        g.move_to(pad_x + line_w + 4, ly + 3);
        g.show_text("ch " + (i + 1));
    }
}