autowatch=1;

const path = require('path');
const fs = require('fs');
const Max = require('max-api');

Max.addHandler('init', (patcherDir) => {
    if (!patcherDir) {
        Max.post('init: no patcherDir given', Max.POST_LEVELS.ERROR);
        return;
    }
    const buffersDir = path.join(patcherDir, 'buffers');
    try {
        fs.mkdirSync(buffersDir, {recursive: true});
        Max.outlet('ready', buffersDir);
    } catch (e) {
        Max.post('mkdir failed: ' + e.message, Max.POST_LEVELS.ERROR);
    }
});