inlets = 1;
outlets = 1;
autowatch = 1;

function getBuffersPath() {
	var patcher_path = this.patcher.filepath;
	var sepIndex = Math.max(patcher_path.lastIndexOf("/"), patcher_path.lastIndexOf("\\"));
    var path = patcher_path.substring(0, sepIndex);
    return path + "/buffers";
}

var buffers_path = getBuffersPath();

function newUUID() {
  	var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    	var r = Math.random() * 16 | 0;
    	var v = c === 'x' ? r : (r & 0x3 | 0x8);
    	return v.toString(16);
  	});
  	outlet(0, "uuid", uuid);
}

function buffersPath() {
	outlet(0, "path", buffers_path); 
}