autowatch = 1;

var p = this.patcher;
var priorObj;
var currentModelName;

function deletePrior() {
  priorObj = p.getnamed("prior_object");
  if (priorObj) {
    p.remove(priorObj);
  }
}

function createPrior(modelName) {
  if (modelName === currentModelName) {
    return;
  }

  currentModelName = modelName;
  
  deletePrior();

  priorObj = p.newdefault(134, 640, "nn~", modelName, "prior", 8192);
  priorObj.varname = "prior_object";
  priorObj.rect = [134., 640., 800., 22.];

  var priorInputReceive = p.getnamed("prior_input_receive");
  p.connect(priorInputReceive, 0, priorObj, 0);

  var priorInputObj = p.getnamed("prior_input_object");
  p.connect(priorInputObj, 0, priorObj, 0);
  p.connect(priorInputObj, 1, priorObj, 1);
  p.connect(priorInputObj, 2, priorObj, 2);
  p.connect(priorInputObj, 3, priorObj, 3);
  p.connect(priorInputObj, 4, priorObj, 4);
  p.connect(priorInputObj, 5, priorObj, 5);
  p.connect(priorInputObj, 6, priorObj, 6);
  p.connect(priorInputObj, 7, priorObj, 7);
  p.connect(priorInputObj, 8, priorObj, 8);
  p.connect(priorInputObj, 9, priorObj, 9);

  var pL1SendObj = p.getnamed("p-l1_send~");
  p.connect(priorObj, 0, pL1SendObj, 0);
  var pL2SendObj = p.getnamed("p-l2_send~");
  p.connect(priorObj, 1, pL2SendObj, 0);
  var pL3SendObj = p.getnamed("p-l3_send~");
  p.connect(priorObj, 2, pL3SendObj, 0);
  var pL4SendObj = p.getnamed("p-l4_send~");
  p.connect(priorObj, 3, pL4SendObj, 0);
}
