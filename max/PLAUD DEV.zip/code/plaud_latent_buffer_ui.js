mgraphics.init();
mgraphics.relative_coords = 0;
mgraphics.autofill = 0;

autowatch = 1;
inlets = 7;
outlets = 2;

setinletassist(0, "bang to redraw / set <name> / region <start> <end>");
setinletassist(1, "channel select (0=all, 1=ch1, 2=ch2...)");
setinletassist(2, "selection start (normalised 0..1)");
setinletassist(3, "selection length (normalised 0..1)");
setinletassist(4, "playhead position (normalised 0..1)");
setinletassist(5, "recording head position (normalised 0..1)");
setinletassist(6, "grid ticks (samples per division, 0 = off)");

setoutletassist(0, "selection start (normalised 0..1)");
setoutletassist(1, "selection end (normalised 0..1)");

var buf_name    = "";
var selected_ch = -1;
var sel_start   = 0.0;
var sel_end     = 1.0;
var drag_anchor = 0.0;
var drag_mode   = "none";
var drag_offset_start = 0.0;
var drag_offset_end   = 0.0;
var marker_thresh = 6;
var hover_zone    = "none";
var zoom          = 1.0;
var scroll        = 0.0;
var playhead      = 0.0;
var rechead       = -1.0;
var grid_ticks    = 0;
var n_frames_last = 1;
var ignore_inlets = false;

var sb_dragging    = false;
var sb_drag_origin = 0.0;
var sb_drag_scroll = 0.0;

var ctrl_h = 14;
var sb_h   = 5;
var btn_w  = 14;
var btn_h  = 8;
var btn_gap = 2;

var btn_plus  = {};
var btn_minus = {};
var sb_rect   = {};

var colors = [
    [0.11, 0.62, 0.46],
    [0.22, 0.54, 0.87],
    [0.94, 0.62, 0.15],
    [0.83, 0.33, 0.49],
    [0.50, 0.47, 0.87],
    [0.36, 0.79, 0.65],
    [0.94, 0.60, 0.48],
    [0.71, 0.83, 0.96],
];

var overlay_color = [0.11, 0.62, 0.46, 0.18];

// ── helpers ───────────────────────────────────────────────

function clamp(v, lo, hi) {
    return Math.max(lo, Math.min(hi, v));
}

function get_view_start() {
    return scroll * (1.0 - 1.0 / zoom);
}

function get_view_size() {
    return 1.0 / zoom;
}

function buf_to_screen(norm, W) {
    return (norm - get_view_start()) / get_view_size() * W;
}

function screen_to_buf(x, W) {
    return get_view_start() + (x / W) * get_view_size();
}

function get_zone(x, y, W, H) {
    if (y >= H - ctrl_h) return "controls";
    var sx1 = buf_to_screen(sel_start, W);
    var sx2 = buf_to_screen(sel_end,   W);
    if (Math.abs(x - sx1) <= marker_thresh) return "start";
    if (Math.abs(x - sx2) <= marker_thresh) return "end";
    if (x > sx1 && x < sx2) return "region";
    return "outside";
}

// snap a normalised value to the nearest grid division
function snap_to_grid(v) {
    if (grid_ticks <= 0 || n_frames_last <= 0) return v;
    var grid_norm = grid_ticks / n_frames_last;
    if (grid_norm <= 0) return v;
    return Math.round(v / grid_norm) * grid_norm;
}

function emit_region() {
    ignore_inlets = true;
    outlet(0, sel_start);
    outlet(1, sel_end);
    ignore_inlets = false;
}

function apply_region(s, e) {
    s = clamp(s, 0.0, 1.0);
    e = clamp(e, s, 1.0);
    sel_start = s;
    sel_end   = e;
    emit_region();
    mgraphics.redraw();
}

function do_zoom(factor) {
    var sel_centre = (sel_start + sel_end) * 0.5;
    var old_vz     = get_view_size();
    var old_vs     = get_view_start();
    var new_zoom   = clamp(zoom * factor, 1.0, 32.0);
    var new_vz     = 1.0 / new_zoom;
    var screen_pos = (sel_centre - old_vs) / old_vz;
    var new_vs     = sel_centre - screen_pos * new_vz;
    zoom = new_zoom;
    if (zoom <= 1.0) {
        scroll = 0.0;
    } else {
        scroll = clamp(new_vs / (1.0 - new_vz), 0.0, 1.0);
    }
    mgraphics.redraw();
}

function hit(x, y, r) {
    return x >= r.x && x <= r.x + r.w && y >= r.y && y <= r.y + r.h;
}

// ── inlets ────────────────────────────────────────────────

function set(name) {
    buf_name = name;
    mgraphics.redraw();
}

function bang() {
    mgraphics.redraw();
}

function region(s, e) {
    apply_region(s, e);
}

function try_set_start_preserve_length(v) {
    var new_start = clamp(v, 0.0, 1.0);
    new_start = snap_to_grid(new_start);
    var len = sel_end - sel_start;
    // clamp start so end stays within [0, 1]
    var max_start = 1.0 - len;
    // snap max_start down to grid to ensure it's a valid grid position
    if (grid_ticks > 0 && n_frames_last > 0) {
        var grid_norm = grid_ticks / n_frames_last;
        max_start = Math.floor(max_start / grid_norm) * grid_norm;
    }
    if (new_start > max_start) new_start = max_start;
    if (new_start < 0.0) new_start = 0.0;
    var new_end = new_start + len;
    // safety: if length somehow exceeds available space, refuse
    if (new_end > 1.0 + 1e-9 || new_start >= new_end) return false;
    sel_start = new_start;
    sel_end   = new_end;
    return true;
}

function try_set_end(v) {
    var new_end = clamp(v, 0.0, 1.0);
    new_end = snap_to_grid(new_end);
    if (new_end > 1.0 + 1e-9 || new_end <= sel_start) return false;
    sel_end = new_end;
    return true;
}

function msg_float(v) {
    if (ignore_inlets) return;

    if (inlet == 2) {
        if (try_set_start_preserve_length(v)) {
            emit_region();
            mgraphics.redraw();
        }

    } else if (inlet == 3) {
        var new_len = clamp(v, 0.0, 1.0);
        var new_end = sel_start + new_len;
        if (try_set_end(new_end)) {
            emit_region();
            mgraphics.redraw();
        }

    } else if (inlet == 4) {
        playhead = clamp(v, 0.0, 1.0);
        mgraphics.redraw();
    } else if (inlet == 5) {
        rechead = v;
        mgraphics.redraw();
    } else if (inlet == 6) {
        grid_ticks = Math.max(0, Math.round(v));
        mgraphics.redraw();
    }
}

function msg_int(v) {
    if (inlet == 1) {
        selected_ch = (v == 0) ? -1 : (v - 1);
        mgraphics.redraw();
    } else {
        msg_float(v);
    }
}

// ── paint ─────────────────────────────────────────────────

function paint() {
    var g      = mgraphics;
    var W      = box.rect[2] - box.rect[0];
    var H      = box.rect[3] - box.rect[1];
    var draw_H = H - ctrl_h;

    var btn_y   = H - ctrl_h + (ctrl_h - btn_h) * 0.5;
    btn_plus.x  = W - btn_w - btn_gap;
    btn_plus.y  = btn_y;
    btn_plus.w  = btn_w;
    btn_plus.h  = btn_h;
    btn_minus.x = W - btn_w * 2 - btn_gap * 2;
    btn_minus.y = btn_y;
    btn_minus.w = btn_w;
    btn_minus.h = btn_h;

    var label_w  = 20;
    var sb_right = btn_minus.x - btn_gap - label_w - btn_gap;
    sb_rect.x    = 0;
    sb_rect.y    = H - ctrl_h + (ctrl_h - sb_h) * 0.5;
    sb_rect.w    = sb_right;
    sb_rect.h    = sb_h;

    g.set_source_rgba(0.07, 0.07, 0.08, 1.0);
    g.rectangle(0, 0, W, H);
    g.fill();

    var vs   = get_view_start();
    var vz   = get_view_size();
    var vend = vs + vz;

    if (grid_ticks > 0 && n_frames_last > 0) {
        var grid_norm   = grid_ticks / n_frames_last;
        var grid_px     = grid_norm / vz * W;
        var min_grid_px = 4;

        if (grid_px >= min_grid_px) {
            g.set_source_rgba(1.0, 1.0, 1.0, 0.1);
            g.set_line_width(0.5);

            var first_norm = Math.ceil(vs / grid_norm) * grid_norm;
            for (var gn = first_norm; gn <= vend + grid_norm * 0.5; gn += grid_norm) {
                gn = Math.round(gn / grid_norm) * grid_norm;
                if (gn < 0.0 || gn > 1.0 + grid_norm * 0.5) continue;
                var gx = buf_to_screen(gn, W);
                if (gx < -1 || gx > W + 1) continue;
                g.move_to(gx, 0);
                g.line_to(gx, draw_H);
                g.stroke();
            }
        }
    }

    var ph_x = buf_to_screen(playhead, W);
    if (ph_x >= 0 && ph_x <= W) {
        g.set_source_rgba(1.0, 0.85, 0.2, 0.12);
        g.set_line_width(5.0);
        g.move_to(ph_x, 0);
        g.line_to(ph_x, draw_H);
        g.stroke();
    }

    var rh_x = (rechead >= 0.0) ? buf_to_screen(rechead, W) : -1;
    if (rh_x >= 0 && rh_x <= W) {
        g.set_source_rgba(1.0, 0.18, 0.18, 0.15);
        g.set_line_width(5.0);
        g.move_to(rh_x, 0);
        g.line_to(rh_x, draw_H);
        g.stroke();
    }

    if (buf_name == "") {
        draw_controls(g, W, H, draw_H);
        return;
    }

    var buf      = new Buffer(buf_name);
    var n_frames = buf.framecount();
    var n_chans  = buf.channelcount();

    if (n_frames < 2 || n_chans < 1) {
        g.set_source_rgba(1.0, 1.0, 1.0, 0.15);
        g.set_font_size(10);
        g.move_to(W * 0.5 - 30, draw_H * 0.5 + 4);
        g.show_text("no buffer");
        draw_playhead_sharp(g, ph_x, draw_H);
        draw_rechead_sharp(g, rh_x, draw_H);
        draw_controls(g, W, H, draw_H);
        return;
    }

    n_frames_last = n_frames;

    var sx1 = buf_to_screen(sel_start, W);
    var sx2 = buf_to_screen(sel_end,   W);

    g.set_source_rgba(1.0, 1.0, 1.0, 0.04);
    g.rectangle(sx1, 0, sx2 - sx1, draw_H);
    g.fill();

    if (hover_zone == "region") {
        g.set_source_rgba(1.0, 1.0, 1.0, 0.04);
        g.rectangle(sx1, 0, sx2 - sx1, draw_H);
        g.fill();
    }

    g.set_source_rgba(1.0, 1.0, 1.0, 0.05);
    g.set_line_width(0.5);
    g.move_to(0, draw_H * 0.5);
    g.line_to(W, draw_H * 0.5);
    g.stroke();

    var ch_from, ch_to;
    if (selected_ch == -1) {
        ch_from = 0; ch_to = n_chans - 1;
    } else {
        ch_from = Math.min(selected_ch, n_chans - 1);
        ch_to   = ch_from;
    }

    var step      = Math.max(1, Math.floor(n_frames * vz / W));
    var draw_from = Math.max(0.0, vs);
    var draw_to   = Math.min(1.0, vend);

    for (var ch = ch_from; ch <= ch_to; ch++) {
        var col = colors[ch % colors.length];
        draw_segment(g, buf, ch, n_frames, W, draw_H, step,
                     draw_from, Math.min(sel_start, draw_to),
                     col[0], col[1], col[2], 0.7, 0.8, vs, vz);
        draw_segment(g, buf, ch, n_frames, W, draw_H, step,
                     Math.max(sel_start, draw_from), Math.min(sel_end, draw_to),
                     col[0], col[1], col[2], 1.0, 1.4, vs, vz);
        draw_segment(g, buf, ch, n_frames, W, draw_H, step,
                     Math.max(sel_end, draw_from), draw_to,
                     col[0], col[1], col[2], 0.7, 0.8, vs, vz);
    }

    g.set_source_rgba(overlay_color[0], overlay_color[1], overlay_color[2], overlay_color[3]);
    g.rectangle(sx1, 0, sx2 - sx1, draw_H);
    g.fill();

    var tick_h      = 6;
    var start_alpha = (hover_zone == "start") ? 1.0 : 0.9;
    var end_alpha   = (hover_zone == "end")   ? 1.0 : 0.9;
    var start_lw    = (hover_zone == "start") ? 2.0 : 1.0;
    var end_lw      = (hover_zone == "end")   ? 2.0 : 1.0;

    g.set_source_rgba(1.0, 1.0, 1.0, start_alpha);
    g.set_line_width(start_lw);
    g.move_to(sx1, 0); g.line_to(sx1, draw_H); g.stroke();
    g.set_line_width(start_lw + 1.0);
    g.move_to(sx1, 0);      g.line_to(sx1 + tick_h, 0);      g.stroke();
    g.move_to(sx1, draw_H); g.line_to(sx1 + tick_h, draw_H); g.stroke();

    if (hover_zone == "start") {
        g.set_source_rgba(1.0, 1.0, 1.0, 0.15);
        g.set_line_width(6.0);
        g.move_to(sx1, 0); g.line_to(sx1, draw_H); g.stroke();
    }

    g.set_source_rgba(1.0, 1.0, 1.0, end_alpha);
    g.set_line_width(end_lw);
    g.move_to(sx2, 0); g.line_to(sx2, draw_H); g.stroke();
    g.set_line_width(end_lw + 1.0);
    g.move_to(sx2, 0);      g.line_to(sx2 - tick_h, 0);      g.stroke();
    g.move_to(sx2, draw_H); g.line_to(sx2 - tick_h, draw_H); g.stroke();

    if (hover_zone == "end") {
        g.set_source_rgba(1.0, 1.0, 1.0, 0.15);
        g.set_line_width(6.0);
        g.move_to(sx2, 0); g.line_to(sx2, draw_H); g.stroke();
    }

    if (hover_zone == "region") {
        var cx = (sx1 + sx2) * 0.5;
        var cy = draw_H * 0.5;
        var aw = 8;
        g.set_source_rgba(1.0, 1.0, 1.0, 0.4);
        g.set_line_width(1.2);
        g.move_to(cx - aw, cy);     g.line_to(cx - aw * 2, cy);          g.stroke();
        g.move_to(cx - aw * 2, cy); g.line_to(cx - aw * 2 + 4, cy - 3);  g.stroke();
        g.move_to(cx - aw * 2, cy); g.line_to(cx - aw * 2 + 4, cy + 3);  g.stroke();
        g.move_to(cx + aw, cy);     g.line_to(cx + aw * 2, cy);          g.stroke();
        g.move_to(cx + aw * 2, cy); g.line_to(cx + aw * 2 - 4, cy - 3);  g.stroke();
        g.move_to(cx + aw * 2, cy); g.line_to(cx + aw * 2 - 4, cy + 3);  g.stroke();
    }

    draw_playhead_sharp(g, ph_x, draw_H);
    draw_rechead_sharp(g, rh_x, draw_H);

    g.set_source_rgba(1.0, 1.0, 1.0, 0.5);
    g.set_font_size(9);
    if (sx1 < W - 30) { g.move_to(sx1 + 3, 10); }
    else               { g.move_to(sx1 - 22, 10); }
    g.show_text(sel_start.toFixed(2));

    if (sx2 > 25) { g.move_to(sx2 - 22, draw_H - 4); }
    else          { g.move_to(sx2 + 3,  draw_H - 4); }
    g.show_text(sel_end.toFixed(2));

    draw_controls(g, W, H, draw_H);
}

function draw_playhead_sharp(g, ph_x, draw_H) {
    if (ph_x < 0 || ph_x > box.rect[2] - box.rect[0]) return;
    g.set_source_rgba(1.0, 0.85, 0.2, 0.85);
    g.set_line_width(1.0);
    g.move_to(ph_x, 0);
    g.line_to(ph_x, draw_H);
    g.stroke();
    g.set_source_rgba(1.0, 0.85, 0.2, 0.85);
    g.move_to(ph_x - 4, 0);
    g.line_to(ph_x + 4, 0);
    g.line_to(ph_x, 7);
    g.close_path();
    g.fill();
}

function draw_rechead_sharp(g, rh_x, draw_H) {
    if (rh_x < 0 || rh_x > box.rect[2] - box.rect[0]) return;
    g.set_source_rgba(1.0, 0.18, 0.18, 0.9);
    g.set_line_width(1.0);
    g.move_to(rh_x, 0);
    g.line_to(rh_x, draw_H);
    g.stroke();
    g.set_source_rgba(1.0, 0.18, 0.18, 0.9);
    g.move_to(rh_x - 4, draw_H);
    g.line_to(rh_x + 4, draw_H);
    g.line_to(rh_x, draw_H - 7);
    g.close_path();
    g.fill();
}

function draw_controls(g, W, H, draw_H) {
    var vs = get_view_start();
    var vz = get_view_size();

    g.set_source_rgba(1.0, 1.0, 1.0, 0.06);
    g.set_line_width(0.5);
    g.move_to(0, H - ctrl_h);
    g.line_to(W, H - ctrl_h);
    g.stroke();

    g.set_source_rgba(1.0, 1.0, 1.0, 0.06);
    g.rectangle(sb_rect.x, sb_rect.y, sb_rect.w, sb_rect.h);
    g.fill();

    var sel_x1 = sel_start * sb_rect.w;
    var sel_x2 = sel_end   * sb_rect.w;
    g.set_source_rgba(0.11, 0.62, 0.46, 0.4);
    g.rectangle(sel_x1, sb_rect.y, sel_x2 - sel_x1, sb_rect.h);
    g.fill();

    var ph_sb = playhead * sb_rect.w;
    g.set_source_rgba(1.0, 0.85, 0.2, 0.6);
    g.set_line_width(0.8);
    g.move_to(ph_sb, sb_rect.y);
    g.line_to(ph_sb, sb_rect.y + sb_rect.h);
    g.stroke();

    if (rechead >= 0.0) {
        var rh_sb = rechead * sb_rect.w;
        g.set_source_rgba(1.0, 0.18, 0.18, 0.7);
        g.set_line_width(0.8);
        g.move_to(rh_sb, sb_rect.y);
        g.line_to(rh_sb, sb_rect.y + sb_rect.h);
        g.stroke();
    }

    var thumb_x = sb_rect.x + vs * sb_rect.w;
    var thumb_w = vz * sb_rect.w;
    g.set_source_rgba(1.0, 1.0, 1.0, zoom > 1.01 ? 0.35 : 0.15);
    g.rectangle(thumb_x, sb_rect.y, thumb_w, sb_rect.h);
    g.fill();

    var lx = btn_minus.x - btn_gap - 18;
    var ly = H - ctrl_h + ctrl_h * 0.5 + 3;
    g.set_source_rgba(1.0, 1.0, 1.0, 0.25);
    g.set_font_size(8);
    g.move_to(lx, ly);
    g.show_text(zoom > 1.01 ? zoom.toFixed(1) + "x" : "1x");

    var is_min = (zoom <= 1.0);
    g.set_source_rgba(1.0, 1.0, 1.0, is_min ? 0.06 : 0.12);
    g.rectangle(btn_minus.x, btn_minus.y, btn_minus.w, btn_minus.h);
    g.fill();
    g.set_source_rgba(1.0, 1.0, 1.0, is_min ? 0.15 : 0.6);
    g.set_line_width(1.0);
    var mcy = btn_minus.y + btn_minus.h * 0.5;
    g.move_to(btn_minus.x + 2,               mcy);
    g.line_to(btn_minus.x + btn_minus.w - 2, mcy);
    g.stroke();

    var is_max = (zoom >= 32.0);
    g.set_source_rgba(1.0, 1.0, 1.0, is_max ? 0.06 : 0.12);
    g.rectangle(btn_plus.x, btn_plus.y, btn_plus.w, btn_plus.h);
    g.fill();
    g.set_source_rgba(1.0, 1.0, 1.0, is_max ? 0.15 : 0.6);
    g.set_line_width(1.0);
    var pcx = btn_plus.x + btn_plus.w * 0.5;
    var pcy = btn_plus.y + btn_plus.h * 0.5;
    g.move_to(pcx, btn_plus.y + 2);
    g.line_to(pcx, btn_plus.y + btn_plus.h - 2);
    g.stroke();
    g.move_to(btn_plus.x + 2,               pcy);
    g.line_to(btn_plus.x + btn_plus.w - 2,  pcy);
    g.stroke();
}

// ── draw segment ──────────────────────────────────────────

function draw_segment(g, buf, ch, n_frames, W, H, step, norm_from, norm_to, r, g2, b, alpha, lw, vs, vz) {
    if (norm_from >= norm_to) return;
    var f_from = Math.floor(norm_from * (n_frames - 1));
    var f_to   = Math.ceil(norm_to   * (n_frames - 1));
    g.set_source_rgba(r, g2, b, alpha);
    g.set_line_width(lw);
    var first = true;
    for (var f = f_from; f <= f_to; f += step) {
        var ff   = Math.min(f, n_frames - 1);
        var s    = buf.peek(ch + 1, ff);
        var norm = ff / (n_frames - 1);
        var x    = (norm - vs) / vz * W;
        var y    = H * 0.5 - (s * H * 0.45);
        if (first) { g.move_to(x, y); first = false; }
        else        { g.line_to(x, y); }
    }
    g.stroke();
}

// ── mouse ─────────────────────────────────────────────────

function onclick(x, y, but, cmd, shift, capslock, opt, ctrl) {
    var W = box.rect[2] - box.rect[0];
    var H = box.rect[3] - box.rect[1];

    if (hit(x, y, btn_plus))  { do_zoom(2.0); return; }
    if (hit(x, y, btn_minus)) { do_zoom(0.5); return; }

    if (hit(x, y, sb_rect) && zoom > 1.0) {
        var vs      = get_view_start();
        var vz      = get_view_size();
        var thumb_x = sb_rect.x + vs * sb_rect.w;
        var thumb_w = vz * sb_rect.w;
        if (x >= thumb_x && x <= thumb_x + thumb_w) {
            drag_mode      = "scrollbar";
            sb_dragging    = true;
            sb_drag_origin = x;
            sb_drag_scroll = scroll;
        } else {
            var new_vs = (x - sb_rect.x) / sb_rect.w - vz * 0.5;
            scroll     = clamp(new_vs / (1.0 - vz), 0.0, 1.0);
            mgraphics.redraw();
        }
        return;
    }

    var norm  = clamp(screen_to_buf(x, W), 0.0, 1.0);
    drag_mode = get_zone(x, y, W, H);

    if (drag_mode == "controls") return;

    if (drag_mode == "region") {
        drag_offset_start = norm - sel_start;
        drag_offset_end   = sel_end - norm;
    } else if (drag_mode == "outside") {
        drag_mode   = "new";
        drag_anchor = snap_to_grid(norm);
        if (drag_anchor < 0.0) drag_anchor = 0.0;
        var grid_norm = (grid_ticks > 0 && n_frames_last > 0)
                            ? grid_ticks / n_frames_last : 0.001;
        var tentative_end = clamp(drag_anchor + grid_norm, 0.0, 1.0);
        if (tentative_end > drag_anchor) {
            sel_start = drag_anchor;
            sel_end   = tentative_end;
            emit_region();
        }
    }
    mgraphics.redraw();
}

function ondrag(x, y, but, cmd, shift, capslock, opt, ctrl) {
    var W = box.rect[2] - box.rect[0];

    if (drag_mode == "scrollbar") {
        var vz     = get_view_size();
        var dx     = x - sb_drag_origin;
        var d_norm = dx / sb_rect.w / (1.0 - vz);
        scroll     = clamp(sb_drag_scroll + d_norm, 0.0, 1.0);
        mgraphics.redraw();
        return;
    }

    if (drag_mode == "controls" || drag_mode == "none") return;

    var norm = clamp(screen_to_buf(x, W), 0.0, 1.0);
    var changed = false;

	if (drag_mode == "start") {
    	if (try_set_start_preserve_length(norm)) changed = true;
	} else if (drag_mode == "end") {
    	if (try_set_end(norm)) changed = true;
    } else if (drag_mode == "region") {
        var region_len = sel_end - sel_start;
        var new_start  = norm - drag_offset_start;
        var new_end    = norm + drag_offset_end;
        if (new_start < 0.0) { new_start = 0.0; new_end = region_len; }
        if (new_end   > 1.0) { new_end = 1.0; new_start = 1.0 - region_len; }
        var snapped_start = snap_to_grid(new_start);
        var snapped_end   = snapped_start + region_len;
        if (snapped_start >= 0.0 && snapped_end <= 1.0 + 1e-9) {
            sel_start = snapped_start;
            sel_end   = snapped_end;
            changed = true;
        }

    } else if (drag_mode == "new") {
        var snapped = snap_to_grid(clamp(norm, 0.0, 1.0));
        if (snapped < drag_anchor) {
            if (snapped >= 0.0 && drag_anchor <= 1.0 && snapped < drag_anchor) {
                sel_start = snapped;
                sel_end   = drag_anchor;
                changed = true;
            }
        } else if (snapped > drag_anchor) {
            if (drag_anchor >= 0.0 && snapped <= 1.0 + 1e-9) {
                sel_start = drag_anchor;
                sel_end   = snapped;
                changed = true;
            }
        }
    }

    if (changed) {
        emit_region();
        mgraphics.redraw();
    }
}

function onidle(x, y, but, cmd, shift, capslock, opt, ctrl) {
    var W        = box.rect[2] - box.rect[0];
    var H        = box.rect[3] - box.rect[1];
    var new_zone = get_zone(x, y, W, H);
    if (new_zone != hover_zone) {
        hover_zone = new_zone;
        mgraphics.redraw();
    }
}

function onidleout() {
    drag_mode   = "none";
    hover_zone  = "none";
    sb_dragging = false;
    mgraphics.redraw();
}