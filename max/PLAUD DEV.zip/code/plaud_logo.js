mgraphics.init();
mgraphics.relative_coords = 0;
mgraphics.autofill = 0;

autowatch = 1;
inlets = 0;
outlets = 0;

var time     = 0.0;
var task     = null;
var rot_y    = 0.0;
var rot_x    = 0.3;
var n_spokes = 8;

function bang() { mgraphics.redraw(); }

function start() {
    if (task) { task.cancel(); task = null; }
    task = new Task(tick, this);
    task.interval = 50;
    task.repeat();
}

function tick() {
    rot_y += 0.018;
    time  += 0.012;
    if (rot_y > Math.PI * 2.0) rot_y -= Math.PI * 2.0;
    mgraphics.redraw();
}

function rot_Y(x, y, z, a) {
    return { x: x*Math.cos(a)+z*Math.sin(a), y: y, z: -x*Math.sin(a)+z*Math.cos(a) };
}
function rot_X(x, y, z, a) {
    return { x: x, y: y*Math.cos(a)-z*Math.sin(a), z: y*Math.sin(a)+z*Math.cos(a) };
}
function transform(x, y, z) {
    var p = rot_Y(x, y, z, rot_y);
    return rot_X(p.x, p.y, p.z, rot_x);
}
function project(p, cx, cy, R) {
    var fov = 2.8;
    var z   = p.z + fov;
    if (z < 0.01) z = 0.01;
    var s = fov / z;
    return { x: cx + p.x * R * s, y: cy + p.y * R * s, z: p.z };
}

function spoke_len(i) {
    var phase = i * 2.399;
    return 1.0 + Math.sin(time + phase) * 0.12
               + Math.sin(time * 1.618 + phase * 0.7) * 0.05;
}

function paint() {
    var g  = mgraphics;
    var W  = box.rect[2] - box.rect[0];
    var H  = box.rect[3] - box.rect[1];

    // mark sits on left, text on right
    // mark diameter ~ H
    var or  = H * 0.36;
    var ox  = H * 0.5;
    var oy  = H * 0.5;

    // ── build spoke dirs (golden sphere) ─────────────────
    var dirs = [];
    var golden = Math.PI * (3.0 - Math.sqrt(5.0));
    for (var i = 0; i < n_spokes; i++) {
        var lat = Math.acos(1.0 - 2.0 * (i + 0.5) / n_spokes);
        var lon = golden * i;
        dirs.push({
            x: Math.sin(lat) * Math.cos(lon),
            y: Math.cos(lat),
            z: Math.sin(lat) * Math.sin(lon)
        });
    }

    // project tips
    var tips = [];
    for (var i = 0; i < n_spokes; i++) {
        var d   = dirs[i];
        var len = spoke_len(i);
        var p3  = transform(d.x*len, d.y*len, d.z*len);
        tips.push(project(p3, ox, oy, or));
    }

    // sort back to front
    var order = [];
    for (var i = 0; i < n_spokes; i++) order.push(i);
    order.sort(function(a, b) { return tips[a].z - tips[b].z; });

    // rim connections
    var drawn = {};
    for (var oi = 0; oi < order.length; oi++) {
        var i = order[oi];
        var dists = [];
        for (var j = 0; j < n_spokes; j++) {
            if (j == i) continue;
            var dot = dirs[i].x*dirs[j].x + dirs[i].y*dirs[j].y + dirs[i].z*dirs[j].z;
            dists.push({j:j, dot:dot});
        }
        dists.sort(function(a,b){ return b.dot - a.dot; });
        for (var k = 0; k < Math.min(2, dists.length); k++) {
            var j   = dists[k].j;
            var key = Math.min(i,j) + "_" + Math.max(i,j);
            if (drawn[key]) continue;
            drawn[key] = true;
            var avg_z   = (tips[i].z + tips[j].z) * 0.5;
            var depth_t = (avg_z + 1.0) * 0.5;
            g.set_source_rgba(1.0, 0.6, 0.15, 0.04 + depth_t * 0.06);
            g.set_line_width(0.4);
            g.move_to(tips[i].x, tips[i].y);
            g.line_to(tips[j].x, tips[j].y);
            g.stroke();
        }
    }

    // spokes with bloom
    for (var oi = 0; oi < order.length; oi++) {
        var i       = order[oi];
        var dir     = dirs[i];
        var len     = spoke_len(i);
        var tip     = tips[i];
        var depth_t = (tip.z + 1.0) * 0.5;
        var alpha   = 0.2 + depth_t * 0.7;
        var r_inner = 0.12;

        var dot_up = Math.abs(dir.y);
        var ref    = dot_up > 0.9 ? {x:1,y:0,z:0} : {x:0,y:1,z:0};
        var perp   = {
            x: dir.y*ref.z - dir.z*ref.y,
            y: dir.z*ref.x - dir.x*ref.z,
            z: dir.x*ref.y - dir.y*ref.x
        };
        var plen = Math.sqrt(perp.x*perp.x + perp.y*perp.y + perp.z*perp.z);
        perp.x /= plen; perp.y /= plen; perp.z /= plen;

        var layers = [
            {lw: 4.0, a: 0.03},
            {lw: 2.0, a: 0.07},
            {lw: 1.0, a: alpha}
        ];

        for (var li = 0; li < layers.length; li++) {
            g.set_source_rgba(1.0, 0.65 + depth_t * 0.2, 0.15, layers[li].a);
            g.set_line_width(layers[li].lw);

            var p3_0 = transform(
                dir.x * r_inner + perp.x * 0,
                dir.y * r_inner + perp.y * 0,
                dir.z * r_inner + perp.z * 0
            );
            var s0 = project(p3_0, ox, oy, or);
            g.move_to(s0.x, s0.y);

            var steps = 16;
            for (var s = 1; s <= steps; s++) {
                var t  = s / steps;
                var r  = r_inner + t * (len - r_inner);
                var p3 = transform(dir.x*r, dir.y*r, dir.z*r);
                var sp = project(p3, ox, oy, or);
                g.line_to(sp.x, sp.y);
            }
            g.stroke();
        }

        // tip dot
        g.set_source_rgba(1.0, 0.75, 0.2, 0.08 * depth_t);
        g.arc(tip.x, tip.y, 3.5, 0, Math.PI * 2.0);
        g.fill();
        g.set_source_rgba(1.0, 0.8, 0.3, alpha);
        g.arc(tip.x, tip.y, 1.2, 0, Math.PI * 2.0);
        g.fill();
    }

    // centre orb
    g.set_source_rgba(1.0, 0.55, 0.1, 0.05);
    g.arc(ox, oy, 7, 0, Math.PI * 2.0);
    g.fill();
    g.set_source_rgba(1.0, 0.6, 0.15, 0.15);
    g.arc(ox, oy, 4, 0, Math.PI * 2.0);
    g.fill();
    g.set_source_rgba(1.0, 0.75, 0.25, 0.7);
    g.arc(ox, oy, 2.2, 0, Math.PI * 2.0);
    g.fill();
    g.set_source_rgba(1.0, 0.98, 0.9, 0.95);
    g.arc(ox, oy, 0.9, 0, Math.PI * 2.0);
    g.fill();


    // ── PLAUD ─────────────────────────────────────────────
    var tx = H + 6;
    var ty = H * 0.5;

    // glow
    g.set_source_rgba(1.0, 0.65, 0.2, 0.07);
    g.set_font_size(14);
    g.select_font_face("Arial");
    g.move_to(tx - 1, ty + 5); g.show_text("PLAUD");
    g.move_to(tx + 1, ty + 5); g.show_text("PLAUD");
    g.move_to(tx, ty + 4);     g.show_text("PLAUD");
    g.move_to(tx, ty + 6);     g.show_text("PLAUD");

    // crisp
    g.set_source_rgba(1.0, 1.0, 1.0, 0.95);
    g.set_font_size(14);
    g.move_to(tx, ty + 5);
    g.show_text("PLAUD");

    // version
    g.set_source_rgba(1.0, 0.65, 0.15, 0.5);
    g.set_font_size(8);
    g.move_to(tx + 48, ty + 4);
    g.show_text("DEV");
}

start();